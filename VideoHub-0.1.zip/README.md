# VideoHub 0.1
Android prototype: local link catalog, categories, tags, Android share target, external online playback. No VK API, offline video downloads, or device transfer yet.
Upload all files including .github to repository root. Actions > Build APK > Run workflow (or push) > Artifacts > VideoHub-APK. Extract APK from artifact ZIP.
